var searchData=
[
  ['byte_20ordering_20functions',['Byte Ordering Functions',['../group__byte_orderers.html',1,'']]]
];
