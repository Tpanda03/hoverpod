var searchData=
[
  ['headingmode',['headingMode',['../struct_vpe_basic_control_register.html#a2a92eaae7f0850d6e2eedd6ba2eedb07',1,'VpeBasicControlRegister']]],
  ['hsimode',['hsiMode',['../struct_magnetometer_calibration_control_register.html#a699913c24ed0705b87e33f1c746b153a',1,'MagnetometerCalibrationControlRegister']]],
  ['hsioutput',['hsiOutput',['../struct_magnetometer_calibration_control_register.html#a5ab7b44c6c6cd25daf5f5aac19c4f959',1,'MagnetometerCalibrationControlRegister']]]
];
