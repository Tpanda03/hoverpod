var searchData=
[
  ['x',['x',['../struct_velocity_compensation_status_register.html#ad0da36b2558901e21e7a30f6c227a45e',1,'VelocityCompensationStatusRegister']]],
  ['xdot',['xDot',['../struct_velocity_compensation_status_register.html#aac57e6557fa068eea041770e78f671e8',1,'VelocityCompensationStatusRegister']]]
];
