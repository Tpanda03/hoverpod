var searchData=
[
  ['sensor_20value_20extractors',['Sensor Value Extractors',['../group__sensor_value_extractors.html',1,'']]],
  ['spi_20generate_20read_20functions',['SPI Generate Read Functions',['../group__spi__genread__functions.html',1,'']]],
  ['spi_20generate_20write_20functions',['SPI Generate Write Functions',['../group__spi__genwrite__functions.html',1,'']]]
];
