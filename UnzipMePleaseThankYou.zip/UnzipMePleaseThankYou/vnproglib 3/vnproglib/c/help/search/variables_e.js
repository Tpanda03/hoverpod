var searchData=
[
  ['quat',['quat',['../struct_quaternion_magnetic_acceleration_and_angular_rates_register.html#ae1e178adc8118816ec2da009785d4052',1,'QuaternionMagneticAccelerationAndAngularRatesRegister']]],
  ['quaternion',['quaternion',['../struct_vn_composite_data.html#a61cfa09b4d48bfff612330015e501408',1,'VnCompositeData']]]
];
