var searchData=
[
  ['calculatedmagnetometercalibrationregister',['CalculatedMagnetometerCalibrationRegister',['../struct_calculated_magnetometer_calibration_register.html',1,'']]],
  ['communicationprotocolcontrolregister',['CommunicationProtocolControlRegister',['../struct_communication_protocol_control_register.html',1,'']]]
];
