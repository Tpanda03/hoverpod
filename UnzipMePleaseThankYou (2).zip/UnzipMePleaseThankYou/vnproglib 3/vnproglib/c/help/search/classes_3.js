var searchData=
[
  ['deltathetaanddeltavelocityconfigurationregister',['DeltaThetaAndDeltaVelocityConfigurationRegister',['../struct_delta_theta_and_delta_velocity_configuration_register.html',1,'']]],
  ['deltathetaanddeltavelocityregister',['DeltaThetaAndDeltaVelocityRegister',['../struct_delta_theta_and_delta_velocity_register.html',1,'']]]
];
