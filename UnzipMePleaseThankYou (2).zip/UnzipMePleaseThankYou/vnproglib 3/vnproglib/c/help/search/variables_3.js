var searchData=
[
  ['data',['data',['../struct_vn_uart_packet.html#abe222f6d3581e7920dcad5306cc906a8',1,'VnUartPacket::data()'],['../struct_vn_port_info.html#a6f1fcd712c3f5776853626b2dd03df97',1,'VnPortInfo::data()']]],
  ['datasize',['dataSize',['../struct_vn_port_info.html#a78f9703861dd365a513c2c5aab9f9239',1,'VnPortInfo']]],
  ['deltalimitpos',['deltaLimitPos',['../struct_ins_advanced_configuration_register.html#a022ade72f149eeebca0406e3b12159c3',1,'InsAdvancedConfigurationRegister']]],
  ['deltalimitvel',['deltaLimitVel',['../struct_ins_advanced_configuration_register.html#a1e6cceff6cbbf90ff2206a9fb7b7baa5',1,'InsAdvancedConfigurationRegister']]],
  ['deltatheta',['deltaTheta',['../struct_vn_composite_data.html#aa092a4d41f672ccf2fa814da4e79032c',1,'VnCompositeData::deltaTheta()'],['../struct_delta_theta_and_delta_velocity_register.html#aa092a4d41f672ccf2fa814da4e79032c',1,'DeltaThetaAndDeltaVelocityRegister::deltaTheta()']]],
  ['deltatime',['deltaTime',['../struct_vn_composite_data.html#a1a61318ed6aa02b4ff346e7eb8f68891',1,'VnCompositeData::deltaTime()'],['../struct_delta_theta_and_delta_velocity_register.html#a1a61318ed6aa02b4ff346e7eb8f68891',1,'DeltaThetaAndDeltaVelocityRegister::deltaTime()']]],
  ['deltavelocity',['deltaVelocity',['../struct_vn_composite_data.html#afc94796e5da87f7751db5368d218c756',1,'VnCompositeData::deltaVelocity()'],['../struct_delta_theta_and_delta_velocity_register.html#afc94796e5da87f7751db5368d218c756',1,'DeltaThetaAndDeltaVelocityRegister::deltaVelocity()']]],
  ['directioncosinematrix',['directionCosineMatrix',['../struct_vn_composite_data.html#a9b0e6f2f6038bc87368c2a6e560fd8f2',1,'VnCompositeData']]],
  ['disturbancewindow',['disturbanceWindow',['../struct_vpe_magnetometer_advanced_tuning_register.html#a24df44079e2e7927b9f026d7e6460a79',1,'VpeMagnetometerAdvancedTuningRegister::disturbanceWindow()'],['../struct_vpe_accelerometer_advanced_tuning_register.html#a24df44079e2e7927b9f026d7e6460a79',1,'VpeAccelerometerAdvancedTuningRegister::disturbanceWindow()']]]
];
