var searchData=
[
  ['omega',['omega',['../struct_velocity_compensation_status_register.html#a62b90331154d3d45a3136bfe96d41a02',1,'VelocityCompensationStatusRegister']]]
];
