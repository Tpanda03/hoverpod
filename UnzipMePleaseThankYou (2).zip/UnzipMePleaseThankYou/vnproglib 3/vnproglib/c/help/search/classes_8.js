var searchData=
[
  ['quaternionmagneticaccelerationandangularratesregister',['QuaternionMagneticAccelerationAndAngularRatesRegister',['../struct_quaternion_magnetic_acceleration_and_angular_rates_register.html',1,'']]],
  ['quatf',['quatf',['../unionquatf.html',1,'']]]
];
